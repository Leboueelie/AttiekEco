# AttiékEco — Style seulement (couleurs + formes)

Ces 3 fichiers ne contiennent AUCUN écran, AUCUN texte figé — juste la palette
orange/vert/blanc et la forme des champs/boutons, à appliquer à tes écrans
existants.

## 1. Copier les fichiers

Copie le dossier `com/attiekeco/ui/` de cette archive dans ton projet, à :
`app/src/main/java/com/attiekeco/ui/`

Tu obtiens :
```
ui/theme/Color.kt         → la palette de couleurs
ui/theme/Theme.kt         → le thème Material3 (AttiekEcoTheme)
ui/components/AttiekComponents.kt → champ de texte + boutons stylés
```

## 2. Activer le thème dans MainActivity

Dans ton `MainActivity.kt`, remplace :
```kotlin
MaterialTheme {
    ...
}
```
par :
```kotlin
import com.attiekeco.ui.theme.AttiekEcoTheme

AttiekEcoTheme {
    ...
}
```

À partir de là, TOUS les composants Material3 standards de ton app
(`Button`, `OutlinedTextField`, `TopAppBar`, `Card`...) prennent automatiquement
les couleurs orange/vert/blanc — sans rien changer d'autre.

## 3. (Optionnel) Utiliser les champs/boutons stylés

Si tu veux en plus la forme arrondie des champs et boutons (comme sur ta
référence Figma), remplace dans tes écrans :

- `OutlinedTextField(...)` → `AttiekTextField(value = ..., onValueChange = ..., label = "...")`
- `Button(...)` → `AttiekPrimaryButton(text = "...", onClick = { ... })`

Import nécessaire :
```kotlin
import com.attiekeco.ui.components.AttiekTextField
import com.attiekeco.ui.components.AttiekPrimaryButton
```

C'est tout — pas d'écran imposé, tu gardes tes écrans et ton contenu tels quels.
