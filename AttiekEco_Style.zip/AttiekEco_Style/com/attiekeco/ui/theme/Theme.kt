package com.attiekeco.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AttiekColorScheme = lightColorScheme(
    primary = AttiekOrange,
    onPrimary = Color.White,
    primaryContainer = AttiekOrangeLight,
    onPrimaryContainer = AttiekOrangeDark,

    secondary = AttiekGreen,
    onSecondary = Color.White,
    secondaryContainer = AttiekGreenLight,
    onSecondaryContainer = AttiekGreenDark,

    tertiary = AttiekBrown,
    onTertiary = Color.White,

    background = AttiekBackground,
    onBackground = AttiekOnBackground,

    surface = AttiekBackground,
    onSurface = AttiekOnBackground,
    surfaceVariant = AttiekSurfaceVariant,
    onSurfaceVariant = AttiekOnBackground
)

@Composable
fun AttiekEcoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AttiekColorScheme,
        typography = AttiekTypography,
        content = content
    )
}
