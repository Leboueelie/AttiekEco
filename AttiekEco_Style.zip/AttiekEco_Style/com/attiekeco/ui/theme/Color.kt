package com.attiekeco.ui.theme

import androidx.compose.ui.graphics.Color

// Orange — action, chaleur, attiéké
val AttiekOrange = Color(0xFFE07A1F)
val AttiekOrangeLight = Color(0xFFFFDCC0)
val AttiekOrangeDark = Color(0xFF3D1F00)

// Vert — valorisation, éco
val AttiekGreen = Color(0xFF2E7D4F)
val AttiekGreenLight = Color(0xFFC8F5D6)
val AttiekGreenDark = Color(0xFF002110)

// Brun — accent terre, statut "collecté"
val AttiekBrown = Color(0xFF6D4C2F)

// Neutres
val AttiekBackground = Color(0xFFFFFBF7)
val AttiekOnBackground = Color(0xFF211A13)
val AttiekSurfaceVariant = Color(0xFFF3E9DE)

// Statuts (utilisés dans les badges)
val StatutEnAttente = Color(0xFF8A8578)
val StatutSignale = AttiekOrange
val StatutCollecte = AttiekGreen
